# 🍽 Inventaire HACCP — La Salle à Manger Grenoble

Application de gestion d'inventaire HACCP pour La Salle à Manger.

## Fonctionnalités
- Inventaire multi-zones (HACCP)
- DLC & alertes températures
- Fiches techniques & food cost
- Traçabilité entrées/sorties
- Carte allergènes (14 allergènes UE)
- Comparateur de prix fournisseurs
- Tableau de bord direction
- Export Excel & PDF
- Mode vocal (Web Speech API)
- PWA installable (hors-ligne)

## Déploiement
Automatique via Netlify à chaque push sur `main`.

## Accès
https://haccp-salle-a-manger.netlify.app
