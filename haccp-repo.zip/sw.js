// ── Service Worker — Inventaire HACCP La Salle à Manger ──
const CACHE_NAME = 'haccp-lsm-v1';
const ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  'https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js',
  'https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js',
];

// Installation : mise en cache de tous les assets
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      // On met en cache les assets locaux uniquement (les CDN peuvent échouer hors ligne)
      return cache.addAll(['/', '/index.html', '/manifest.json'])
        .catch(() => cache.addAll(['/', '/index.html']));
    }).then(() => self.skipWaiting())
  );
});

// Activation : supprimer les anciens caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Stratégie : Network First pour l'app, puis cache si hors ligne
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  
  // Assets CDN : cache first (ils ne changent pas)
  if (url.hostname.includes('jsdelivr.net')) {
    event.respondWith(
      caches.open(CACHE_NAME).then(cache =>
        cache.match(event.request).then(cached => {
          if (cached) return cached;
          return fetch(event.request).then(response => {
            cache.put(event.request, response.clone());
            return response;
          }).catch(() => cached);
        })
      )
    );
    return;
  }

  // App principale : Network First → si pas de réseau, cache
  if (url.pathname === '/' || url.pathname === '/index.html') {
    event.respondWith(
      fetch(event.request).then(response => {
        // Nouvelle version disponible : mettre à jour le cache
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() =>
        // Hors ligne : servir depuis le cache
        caches.match('/index.html')
      )
    );
    return;
  }

  // Autres requêtes : cache first
  event.respondWith(
    caches.match(event.request).then(cached =>
      cached || fetch(event.request).catch(() => new Response('', {status: 503}))
    )
  );
});

// Message de l'app : forcer la mise à jour
self.addEventListener('message', event => {
  if (event.data === 'skipWaiting') self.skipWaiting();
});
